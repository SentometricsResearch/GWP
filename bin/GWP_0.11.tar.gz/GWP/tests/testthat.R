library("testthat")

test_check("GWP")